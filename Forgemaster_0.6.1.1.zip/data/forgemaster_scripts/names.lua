mods.hackslow = mods.hackslow or {}
mods.hackslow.customRaceNames = mods.hackslow.customRaceNames or {}
mods.hackslow.customRaceNames.addonNames = mods.hackslow.customRaceNames.addonNames or {}
mods.hackslow.customRaceNames.addonNames.forgemaster = {
    fm_forgemasterperson = {"Alastair"},
}